from flask import Flask, render_template, request
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn import preprocessing
from statsmodels.tsa.arima.model import ARIMA

# Load the rainfall data from the CSV file
data = pd.read_csv('rain.csv')
le = preprocessing.LabelEncoder()
data['SUBDIVISION'] = le.fit_transform(data['SUBDIVISION'])

columns_to_fill = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', 'ANNUAL', 'Jan-Feb', 'Mar-May', 'Jun-Sep', 'Oct-Dec']
data[columns_to_fill] = data[columns_to_fill].fillna(method='ffill')

# Define the Flask application
app = Flask(__name__)

# Define the route for the home page
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

# Define the route for predicting rainfall
@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        # Get the input from the form
        year = int(request.form['year'])
        model_type = request.form['model_type']
        prediction_type = request.form['prediction_type']

        # Filter the data based on the prediction type
        if prediction_type == 'annual':
            column = 'ANNUAL'
        else:
            column = prediction_type.upper()

        # Prepare the training data
        X_train = data['YEAR'].values.reshape(-1, 1)
        y_train = data[column].values

        # Train the selected model
        if model_type == 'random_forest':
            model = RandomForestRegressor(n_estimators=100, random_state=42)
            model.fit(X_train, y_train)
        elif model_type == 'arima':
            arima_model = ARIMA(y_train, order=(1, 1, 1))
            arima_model_fit = arima_model.fit()

        # Predict the rainfall for the given year using the selected model
        if model_type == 'random_forest':
            prediction = model.predict([[year]])
            predicted_rainfall = prediction[0]
        elif model_type == 'arima':
            predicted_rainfall_arima = arima_model_fit.forecast(steps=1)  # Predict 1 value
            prediction = predicted_rainfall_arima[0]
            predicted_rainfall = prediction

        average_rainfall = data[column].mean()

        if prediction > average_rainfall:
            weather_condition = 'Rainy'
        elif prediction < average_rainfall:
            weather_condition = 'Sunny'
        else:
            weather_condition = 'Cloudy'

        # Render the result template
        return render_template('result.html', year=year, prediction=prediction, prediction_type=prediction_type,
                               model_type=model_type, weather_condition=weather_condition)

    # If the request method is GET, render the form template
    return render_template('index.html')

# Run the Flask application
if __name__ == '__main__':
    app.run()